<?php
  libxml_use_internal_errors(true);
  if(isset($_GET['link'])){
    $dom = new DOMDocument();
    $link = $_GET['link'];
    $dom->loadHTMLFile($link);
    $mgLnk;
    foreach ($dom->getElementsByTagName("a") as $el) {

      if(strpos($el->getAttribute("href"), "magnet:?") !== false){
        //echo $el->getAttribute("href");
        $mgLnk = $el->getAttribute("href");
        break;
      }
    }
    if(isset($mgLnk)){
      echo $mgLnk;
    }
    else {
      echo "Falha ao encontrar link";
    }
  }
 ?>

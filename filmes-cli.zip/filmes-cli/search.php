<?php
libxml_use_internal_errors(true);
class Filme{
  public $name, $image, $link;
  function __construct($n, $i, $l){
    $this->name = $n;
    $this->image = $i;
    $this->link = $l;
  }

}
function getJson($obj){
  return json_encode( (array)$obj);
}
if(isset($_GET['nome'])){
  $items = array();
  $nome = $_GET['nome'];
  $dom = new DOMDocument();
  $dom->loadHTMLFile("http://www.comandotorrents.com/?s=" . str_replace(" ", "+", $nome));
  $posts = $dom->getElementsByTagName("article");
  foreach ($posts as $post) {

    $pNome =  $post->getElementsByTagName("a")[0]->nodeValue;
    $pLink = $post->getElementsByTagName("a")[0]->getAttribute("href");
    $pImagem = urldecode($post->getElementsByTagName("img")[0]->getAttribute("data-lazy-src"));
    $items[] = new Filme($pNome, $pImagem, $pLink);
  }
  echo getJson($items);
}
?>
